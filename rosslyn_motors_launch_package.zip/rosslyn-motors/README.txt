ROSSLYN MOTORS — LAUNCH PREPARATION VERSION

Official details incorporated:
WhatsApp: 0722 811 194 (WhatsApp link uses Kenya country code 254)
Email: rosslynmotors7@gmail.com
Showroom: Nairobi, Kenya
Inventory: Used vehicles

Website prototype includes listings, search/filters, details, comparison, enquiry form and prototype owner controls.

Before launch: owner panel is NOT production secure and uses browser-local storage; replace with Supabase Auth and RLS before relying on it. Confirm sample vehicle listings, images, prices and claims are accurate or replace them. Add privacy notice and test links/contact details.

GitHub Pages: upload index.html to repository root, then Settings > Pages > Deploy from branch > main > root.
